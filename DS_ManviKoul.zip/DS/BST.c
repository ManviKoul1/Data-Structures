//This program demonstrates the use of tree traversal search insert 
//Binary search tree
# include <stdio.h> 
# include <stdlib.h>
 
typedef struct BST {
   int data;
   struct BST *l, *r;
} node;
 
void insert(node *, node *);
void inorder(node *);
void preorder(node *);
void postorder(node *);
node *search(node *, int, node **);
 
void main() {
   int choice;
   char ans = 'N';
   int key;
   node *new_node, *root, *tmp, *parent;
   node *get_node();
   root = NULL;
   
  
   do {
      printf("\ni] Insert");
      printf("\nii].Search");
      printf("\niii]Traverse");
      printf("\niv]Exit");
      printf("\nEnter option :");
      scanf("%d", &choice);
 
      switch (choice) {
      case 1:
         do {
            new_node = get_node();
            printf("\nenter element ");
            scanf("%d", &new_node->data);
 
            if (root == NULL) 
               root = new_node;
            else
               insert(root, new_node);
 
            printf("\nContinue(y/n)");
            ans;
         } while (ans == 'y');
         break;
 
      case 2:
         printf("\nSearch element type :");
         scanf("%d", &key);
 
         tmp = search(root, key, &parent);
         printf("\nParent of node %d is %d", tmp->data, parent->data);
         break;
 
      case 3:
         if (root == NULL)
            printf("Empty tree");
         else {
            printf("\nInorder  : ");
            inorder(root);
            printf("\n Preorder  : ");
            preorder(root);
            printf("\n Postorder  : ");
            postorder(root);
         }
         break;
      }
   } while (choice != 4);
}
 
node *get_node() {
   node *temp;
   temp = (node *) malloc(sizeof(node));
   temp->l = NULL;
   temp->r = NULL;
   return temp;
}
 
void insert(node *root, node *new_node) {
   if (new_node->data < root->data) {
      if (root->l == NULL)
         root->l = new_node;
      else
         insert(root->l, new_node);
   }
 
   if (new_node->data > root->data) {
      if (root->r == NULL)
         root->r = new_node;
      else
         insert(root->r, new_node);
   }
}
 
node *search(node *root, int key, node **parent) {
   node *temp;
   temp = root;
   while (temp != NULL) {
      if (temp->data == key) {
         printf("\n %d Element present", temp->data);
         return temp;
      }
      *parent = temp;
 
      if (temp->data > key)
         temp = temp->l;
      else
         temp = temp->r;
   }
   return NULL;
}

void inorder(node *temp) {
   if (temp != NULL) {
      inorder(temp->l);
      printf("%d", temp->data);
      inorder(temp->r);
   }
}
 
void preorder(node *temp) {
   if (temp != NULL) {
      printf("%d", temp->data);
      preorder(temp->l);
      preorder(temp->r);
   }
}
 
 
void postorder(node *temp) {
   if (temp != NULL) {
      postorder(temp->l);
      postorder(temp->r);
      printf("%d", temp->data);
   }
}
