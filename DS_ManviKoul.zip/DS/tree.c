#include<stdio.h>
#include<stdlib.h>

typedef struct tn
{
        int data;
        struct tn *l;
        struct tn *r;

}tn;

tn* Min(tn *node)
{
        if(node==NULL)
        {
                 
                return NULL;
        }
        if(node->l)  
                return Min(node->l);
        else 
                return node;
}
tn* Max(tn *node)
{
        if(node==NULL)
        {
                 
                return NULL;
        }
        if(node->r) 
                Max(node->r);
        else 
                return node;
}

tn * Insert(tn *node,int data)
{
        if(node==NULL)
        {
                tn *temp;
                temp = (tn *)malloc(sizeof(tn));
                temp -> data = data;
                temp -> l = temp -> r = NULL;
                return temp;
        }

        if(data >(node->data))
        {
                node->r = Insert(node->r,data);
        }
        else if(data < (node->data))
        {
                node->l = Insert(node->l,data);
        }
       
        return node;

}

tn * Delete(tn *node, int data)
{
        tn *temp;
        if(node==NULL)
        {
                printf("Element Not Found");
        }
        else if(data < node->data)
        {
                node->l = Delete(node->l, data);
        }
        else if(data > node->data)
        {
                node->r = Delete(node->r, data);
        }
        else
        {
                 
                if(node->r && node->l)
                {
                        
                        temp = Min(node->r);
                        node -> data = temp->data; 
                       
                        node -> r = Delete(node->r,temp->data);
                }
                else
                {
                       
                        temp = node;
                        if(node->l == NULL)
                                node = node->r;
                        else if(node->r == NULL)
                                node = node->l;
                        free(temp);  
                }
        }
        return node;

}

tn * Find(tn *node, int data)
{
        if(node==NULL)
        {
                 
                return NULL;
        }
        if(data > node->data)
        {
                 
                return Find(node->r,data);
        }
        else if(data < node->data)
        { 
                return Find(node->l,data);
        }
        else
        {
                 
                return node;
        }
}

void PrintInorder(tn *node)
{
        if(node==NULL)
        {
                return;
        }
        PrintInorder(node->l);
        printf("%d ",node->data);
        PrintInorder(node->r);
}

void PrintPreorder(tn *node)
{
        if(node==NULL)
        {
                return;
        }
        printf("%d ",node->data);
        PrintPreorder(node->l);
        PrintPreorder(node->r);
}

void PrintPostorder(tn *node)
{
        if(node==NULL)
        {
                return;
        }
        PrintPostorder(node->l);
        PrintPostorder(node->r);
        printf("%d ",node->data);
}

int main()
{
        tn *root = NULL;
        root = Insert(root, 50);
        root = Insert(root, 25);
        root = Insert(root, 8);
        root = Insert(root, 14);
        root = Insert(root, 68);
        root = Insert(root, 10);
        root = Insert(root, 39);
        root = Insert(root, 26);
        PrintInorder(root);
        printf("\n");
        root = Delete(root,5);
        root = Delete(root,-1);
        PrintInorder(root);
        printf("\n");
        tn * temp;
        temp = Min(root);
        printf("Min:- %d\n",temp->data);
        temp = Max(root);
        printf("Max:- %d\n",temp->data);
        temp = Find(root,8);
        if(temp==NULL)
        {
                printf("Element 8 not found\n");
        }
        else
        {
                printf("Element 8 Found\n");
        }
        temp = Find(root,2);
        if(temp==NULL)
        {
                printf("Element 2 not found\n");
        }
        else
        {
                printf("Element 6 Found\n");
        }
}

